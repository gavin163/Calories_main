package com.example.calories;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.UpdateListener;

public class GeneralMealAdapter extends RecyclerView.Adapter {
    private Context mycontext;
    private ArrayList<Meal> mealList = new ArrayList<Meal>();
    private SharedPreferences mshare;
    private SharedPreferences.Editor mEditor;
   

    public GeneralMealAdapter(Context context, ArrayList<Meal> mealList){
        mycontext = context;
        this.mealList = mealList;
        mshare = mycontext.getSharedPreferences("userdata", Context.MODE_PRIVATE);
        mEditor = mshare.edit();
    }

    public void update(){
//        mealList.clear();
//        mealList = newList;
        notifyDataSetChanged();
    }

    public void swipeToDelete(int position){
        Log.d("Meal", "Before Check the damn size move= "+ String.valueOf(position));
        Meal current = new Meal(mealList.get(position).getMealType(),
                mealList.get(position).getMealName(), mealList.get(position).getTotalCalorie(),
                mealList.get(position).getTotalProtein(), mealList.get(position).getTotalCarb(),
                mealList.get(position).getTotalFat());
        String objectId = mealList.get(position).getObjectId();
        current.setObjectId(objectId);
//        current.setObjectId(objectId);
        current.delete( new UpdateListener() {
            @Override
            public void done(BmobException e) {
                if(e == null){
//                    mealList.remove(position);
                    Log.d("Delete", "Meal "+current.getMealName()+" is deleted");
                }
                else{
                    Log.d("Delete", "Object ID "+e+" is deleted");
                }

            }
        });
        Log.d("Meal", "Before Check the damn size = "+ String.valueOf(mealList.size()));
        float calorie = mshare.getFloat("leftCal", (float) 0.0);
        float protein = mshare.getFloat("leftPro", (float) 0.0);
        float fat = mshare.getFloat("leftFat", (float) 0.0);
        float carb = mshare.getFloat("leftCarb", (float) 0.0);
        mEditor.putFloat("leftCal",  (float) (calorie + mealList.get(position).getTotalCalorie()));
        mEditor.putFloat("leftPro",  (float) (protein + mealList.get(position).getTotalProtein()));
        mEditor.putFloat("leftFat",  (float) (fat + mealList.get(position).getTotalFat()));
        mEditor.putFloat("leftCarb", (float) (carb + mealList.get(position).getTotalCarb()));
        mEditor.commit();
        mealList.remove(position);
        Log.d("Meal", "After Check the damn size = "+ String.valueOf(mealList.size()));
//        return mealList;
        notifyDataSetChanged();
    }

    public class MealViewHolder extends RecyclerView.ViewHolder{
        public TextView mealNameField, mealCalorieField;
        public MealViewHolder(@NonNull View itemView) {
            super(itemView);
            mealNameField = (TextView) itemView.findViewById(R.id.MealNameField);
            mealCalorieField = (TextView)itemView.findViewById(R.id.MealCalorieField);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.meal_item_view,parent,false);
        MealViewHolder holder = new MealViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//        String name = "Apple";
//        String cal = "100";
        String name = mealList.get(position).getMealName();
        String cal = String.valueOf(mealList.get(position).getTotalCalorie());
//        String name = (String) list.get(position)[0];
//        String cal = (String) list.get(position)[1];
//        Log.d("In.... size ", " = "+mealList.size());
        ((MealViewHolder) holder).mealNameField.setText(name);
        ((MealViewHolder) holder).mealCalorieField.setText(cal + " Kcal");
    }

    @Override
    public int getItemCount() {
        return mealList.size();

//        return 10;
    }
}
