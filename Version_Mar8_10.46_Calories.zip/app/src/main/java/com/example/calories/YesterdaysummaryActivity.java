package com.example.calories;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.RatingBar;
import android.content.SharedPreferences;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class YesterdaysummaryActivity extends AppCompatActivity {
//    private ImageView HomeButton;
    private SharedPreferences mshare;
    private RatingBar caloriesbar;
    private RatingBar proteinbar;
    private RatingBar carbbar;
    private RatingBar fatbar;
    private TextView comments;
    private final String lack = "was not satisfied. You should consider to consume more ";
    private final String exceeded = "was beyond what you actually need. You should consider to consume LESS ";
    private final String onPoint = "was satisfied. Good job!";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yesterdaysummary);
        mshare = getSharedPreferences("userdata",MODE_PRIVATE);
        float targetCal = mshare.getFloat("Yesterday Calorie", (float) 0.0);
        double targetProtein = 0.0, targetCarb = 0.0, targetFat = 0.0;
        targetProtein = targetCal * 0.4 / 4;
        targetProtein = Double.parseDouble(new DecimalFormat("###.00").format(targetProtein));
        targetCarb = targetCal * 0.4 / 4;
        targetCarb = Double.parseDouble(new DecimalFormat("###.00").format(targetCarb));
        targetFat = targetCal * 0.2 / 4;
        targetFat = Double.parseDouble(new DecimalFormat("###.00").format(targetFat));
        // =========================== Rating Area ====================================
        caloriesbar = (RatingBar) findViewById(R.id.rateCaloriesstar);
        proteinbar = findViewById(R.id.rateProteinsstar);
        carbbar = findViewById(R.id.rateCarbstar);
        fatbar = findViewById(R.id.rateFatstar);
        comments = findViewById(R.id.comment);
        //=============================input data (need to use an equation to get the actual number!!!!!)==============================
        Date today = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.add(Calendar.DATE, -1); // change it to test ==============================================================
        Date yesterday = calendar.getTime();
        SimpleDateFormat current = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//
        String yesterdayString =  current.format(yesterday).substring(0,11);
        String yesterdayStart = yesterdayString +  " 00:00:00";
        String yesterdayEnd = yesterdayString +  " 23:59:59";

        // ============== Get the meal list of today from bmob ================
        BmobQuery<Meal> query = new BmobQuery<Meal>();
        BmobQuery<Meal> q1 = new BmobQuery<Meal>();
        BmobQuery<Meal> q2 = new BmobQuery<Meal>();
        List<BmobQuery<Meal>> and = new ArrayList<BmobQuery<Meal>>();
        Date dateStart  = null;
        try {
            dateStart = current.parse(yesterdayStart);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q1.addWhereGreaterThanOrEqualTo("createdAt",new BmobDate(dateStart));
        and.add(q1);
        Date dateEnd  = null;
        try {
            dateEnd = current.parse(yesterdayEnd);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q2.addWhereLessThanOrEqualTo("createdAt",new BmobDate(dateEnd));
        and.add(q2);
        query.and(and);
        double finalTargetProtein = targetProtein;
        double finalTargetCarb = targetCarb;
        double finalTargetFat = targetFat;
        query.findObjects(new FindListener<Meal>() {
              @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
              @Override
              public void done(List<Meal> list, BmobException e) {
                  double currentCal = 0.0, currentProtein = 0.0, currentCarb = 0.0, currentFat = 0.0;
                  int redCount = 0;
                  int greenCount = 0;
                  if (e == null) {
                      for (Meal meal : list) {
                          Log.d("meal", meal.getCreatedAt());

                          currentCal += meal.getTotalCalorie();
                          currentProtein += meal.getTotalProtein();
                          currentCarb += meal.getTotalCarb();
                          currentFat += meal.getTotalFat();
                      }
                  }
//                  float calories  = (float) 3.0, protein = (float) 4.4, carb = (float) 5.0, fat = (float) 4.6;
                  //=======================================
                  caloriesbar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                  proteinbar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                  carbbar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                  fatbar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                  float calRate = (float) (5 * currentCal / targetCal);
                  if (calRate > 5) {
                      calRate = 5 - (calRate - 5);
                      calRate = calRate > 0? calRate : 0;
                      caloriesbar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                      if (calRate< 4)
                        redCount++;
                  }
                  else if (calRate < 4)
                  {
                      greenCount++;
                  }

                  float proteinRate = (float) (5 * currentProtein / finalTargetProtein);
                  if (proteinRate > 5) {
                      proteinRate = 5 - (proteinRate - 5);
                      proteinRate = proteinRate > 0? proteinRate : 0;
                      proteinbar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                      if (proteinRate< 4)
                          redCount++;
                  }
                  else if (proteinRate < 4)
                  {
                      greenCount++;
                  }

                  float carbRate = (float) (5 * currentCarb / finalTargetCarb);
                  if (carbRate > 5) {
                      carbRate = 5 - (carbRate - 5);
                      carbRate = carbRate > 0? carbRate : 0;
                      carbbar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                      if (carbRate< 4)
                          redCount++;
                  }
                  else if (carbRate < 4)
                  {
                      greenCount++;
                  }

                  float fatRate = (float) (5 * currentFat / finalTargetFat);
                  if (fatRate > 5) {
                      fatRate = 5 - (fatRate - 5);
                      fatRate = fatRate > 0? fatRate : 0;
                      fatbar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                      if (fatRate< 4)
                          redCount++;
                  }
                  else if (fatRate < 4)
                  {
                      greenCount++;
                  }

                  caloriesbar.setRating(calRate);
                  proteinbar.setRating(proteinRate);
                  carbbar.setRating(carbRate);
                  fatbar.setRating(fatRate);



                  // ========================= Text Area =========================================
                  String greeting =  "What's popping, " + (mshare.getString("gender", "Male").equals("Male") ? "Mr. " : "Ms. ") + mshare.getString("name", "") + ",\n"
                          + "What a beautiful day!\nAccording to dietary intakes summary,\n\n\n";

                  // overeating part.
//                  String summary = "" + "on "+ yesterdayStart+ " " +targetCal + " ";
                  String summary = "";
                  switch(redCount){
                      case 1:
                          summary += "\t* One of the nutrition exceeds the daily recommendation.\n\n";
                          break;
                      case 2:
                          summary += "\t* Two nutrition exceeds the daily recommendation.\n\t  You should be aware of your today's food choices\n\n";
                          break;
                      case 3:
                          summary += "\t* Three types of nutrition exceeds the daily recommendation.\n\t  You should be aware of your today's food choices\n\n";
                          break;
                      case 4:
                          summary += "\t* Over three types of nutrition exceeds the daily recommendation.\n\t  You should be aware of your today's food choices\n\n";
                          break;
                  }
                  switch (greenCount){
                      case 1:
                          summary += "\t* One of the nutrition didn't meet the daily recommendation.\n\n";
                          break;
                      case 2:
                          summary += "\t* Two nutrition didn't meet the daily recommendation.\n\t  You should be aware of your today's food choices\n\n";
                          break;
                      case 3:
                          summary += "\t* Three types of nutrition didn't meet the daily recommendation.\n\t  If you are in diet, be sure to keep your body health. good luck.\n\n";
                          break;
                      case 4:
                          summary += "\t* Over three types of nutrition didn't meet the daily recommendation.\n\t  You should be aware of your today's food choices. If you are in diet, be sure to keep your body health. good luck.\n\n";
                          break;
                  }
                  summary+="\t* Please adjust your dietary intakes for today according to rating and actual needs.";

                  // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
                  comments.setTextColor(Color.BLACK);
                  comments.setText(greeting+summary);


//                  final String proteinComments = "\t * The target of protein ";
//
//
//                  // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
//                  final String carbComments = "\t * The target of carb ";
//                  // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
//                  final String fatComments = "\t * The target of fat ";
//                  // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
//
//                  // intakes missing part.



              }

        });
       // comments.setText(fatRate + " " + targetCarb);
//        float calories  = (float) 3.0, protein = (float) 4.4, carb = (float) 5.0, fat = (float) 4.6;
//        //=======================================
//        caloriesbar.setRating(calories);
//       // setAnimation(caloriesbar, calories);
//        proteinbar.setRating(protein);
//        carbbar.setRating(carb);
//        fatbar.setRating(fat);

//        // ========================= Text Area =========================================
//        final String greeting = "What's popping, " + (mshare.getString("gender","Male").equals("Male")? "Mr. ": "Ms. ") + mshare.getString("name","") + ",\n"
//                                + "What a beautiful day! According to dietary intakes summary, your  \n";
//        final String proteinComments = "\t * The target of protein ";
//
//        // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
//        final String carbComments = "\t * The target of carb ";
//        // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
//        final String fatComments = "\t * The target of fat ";
//        // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
//        final String calComments = "\t * The target of calorie ";
//        // Add a one line if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
    }
}