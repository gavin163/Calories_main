package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class MealActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;

    private Button addBreakfast;
    private Button addLunch;
    private Button addDinner;
    private SharedPreferences mshare;
    private SharedPreferences.Editor mEditor;
    // For the list
    private RecyclerView breakfastList;
    private RecyclerView.LayoutManager breakfastLayoutManager;
    private RecyclerView.Adapter breakfastAdapter;
    private ArrayList<Meal> todayBreakfast = new ArrayList<Meal>();

    private RecyclerView lunchList;
    private RecyclerView.LayoutManager lunchLayoutManager;
    private RecyclerView.Adapter lunchAdapter;
    private ArrayList<Meal> todayLunch = new ArrayList<Meal>();

    private RecyclerView dinnerList;
    private RecyclerView.LayoutManager dinnerLayoutManager;
    private RecyclerView.Adapter dinnerAdapter;
    private ArrayList<Meal> todayDinner = new ArrayList<Meal>();

    private BmobQuery<Meal> query = new BmobQuery<Meal>();
    private List<BmobQuery<Meal>> and = new ArrayList<BmobQuery<Meal>>();
    public MealActivity(){

        this.todayBreakfast = new ArrayList<Meal>();
        this.todayLunch = new ArrayList<Meal>();
        this.todayDinner = new ArrayList<Meal>();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal);
        mshare = getSharedPreferences("userdata",MODE_PRIVATE);
        mEditor = mshare.edit();
        // =========================== Get device's time ===========================
        Date currentdate = new Date();//
        SimpleDateFormat current = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//
        String CurrentTime = current.format(currentdate).substring(0, 11);
        String time = current.format(currentdate).substring(11);
//        Log.d("Date", "Date = "+ CurrentTime);

        // =========================== Breakfast Section ===========================
        breakfastList = (RecyclerView)findViewById(R.id.breakfastList);
        breakfastList.setHasFixedSize(true);
        breakfastLayoutManager = new LinearLayoutManager(getApplicationContext());
        breakfastList.setLayoutManager(breakfastLayoutManager);

        BmobQuery<Meal> q1 = new BmobQuery<Meal>();
        // =================== Use the actual date ============================
//        String start = "2021-02-15 00:00:00";
        String start = CurrentTime + " 00:00:00";
        // ====================================================================
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date  = null;
        try {
            date = sdf.parse(start);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q1.addWhereGreaterThanOrEqualTo("createdAt",new BmobDate(date));
        and.add(q1);

        BmobQuery<Meal> q2 = new BmobQuery<Meal>();
        // =================== Use the actual date ============================
//        String end = "2021-02-15 23:59:59";
        String end = CurrentTime + " 23:59:59";
        // ====================================================================
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1  = null;
        try {
            date1 = sdf1.parse(end);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q2.addWhereLessThanOrEqualTo("createdAt",new BmobDate(date1));
        and.add(q2);
        query.and(and);



//        breakfastAdapter = new GeneralMealAdapter(this, getTodayBreakfast());
//        breakfastList.setAdapter(breakfastAdapter);
        // add food to breakfast
        addBreakfast = findViewById(R.id.addBreakfastButton);
        addBreakfast.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent addFoodToBreakfast = new Intent(MealActivity.this, MealSearchActivity.class);
                Bundle newBundle = new Bundle();
                newBundle.putString("type", "Breakfast");
                addFoodToBreakfast.putExtras(newBundle);
                startActivity(addFoodToBreakfast);
            }
        });

        // =========================== Lunch Section ===========================
        lunchList = (RecyclerView)findViewById(R.id.lunchList);
        lunchList.setHasFixedSize(true);
        lunchLayoutManager = new LinearLayoutManager(getApplicationContext());
        lunchList.setLayoutManager(lunchLayoutManager);

        // add food to lunch
        addLunch = findViewById(R.id.addLunchButton);
        addLunch.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent addFoodToLunch = new Intent(MealActivity.this, MealSearchActivity.class);
                Bundle newBundle = new Bundle();
                newBundle.putString("type", "Lunch");
                addFoodToLunch.putExtras(newBundle);
                startActivity(addFoodToLunch);
            }
        });
        // =========================== Dinner Section ===========================
        dinnerList = (RecyclerView)findViewById(R.id.dinnerList);
        dinnerList.setHasFixedSize(true);
        dinnerLayoutManager = new LinearLayoutManager(getApplicationContext());
        dinnerList.setLayoutManager(dinnerLayoutManager);

        // add food to Dinner
        addDinner = findViewById(R.id.addDinnerButton);
        addDinner.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent addFoodToDinner = new Intent(MealActivity.this, MealSearchActivity.class);
                Bundle newBundle = new Bundle();
                newBundle.putString("type", "Dinner");
                addFoodToDinner.putExtras(newBundle);
                startActivity(addFoodToDinner);
            }
        });


        query.findObjects(new FindListener<Meal>() {
            @Override
            public void done(List<Meal> list, BmobException e) {
//                todayBreakfast = (ArrayList<Meal>) list;
                float currentCal = (float) 0.0;
                float currentPro = (float) 0.0;
                float currentCarb = (float) 0.0;
                float currentFat = (float) 0.0;

                if(e == null){
                    for(Meal meal : list){
                        currentCal += meal.getTotalCalorie();
                        currentPro += meal.getTotalProtein();
                        currentCarb += meal.getTotalCarb();
                        currentFat += meal.getTotalFat();
                        if(meal.getMealType().equals("Breakfast")){
                            Log.d("count ", " = "+ meal.getMealName());
//                        updateBreakfast(meal);
                            todayBreakfast.add(meal);

                        }
                        if(meal.getMealType().equals("Lunch")){
                            todayLunch.add(meal);
                        }
                        if(meal.getMealType().equals("Dinner")){
                            todayDinner.add(meal);
                        }
                    }
                }
//                float calorie = mshare.getFloat("leftCal", (float) 0.0);
//                float protein = mshare.getFloat("leftPro", (float) 0.0);
//                float fat = mshare.getFloat("leftFat", (float) 0.0);
//                float carb = mshare.getFloat("leftCarb", (float) 0.0);
//                mEditor.putFloat("leftCal",  (float) (calorie - currentCal));
//                mEditor.commit();
//                mEditor.putFloat("leftPro",  (float) (protein - currentPro));
//                mEditor.commit();
//                mEditor.putFloat("leftFat",  (float) (fat - currentFat));
//                mEditor.commit();
//                mEditor.putFloat("leftCarb", (float) (carb - currentCarb));
//                mEditor.commit();

                breakfastAdapter = new GeneralMealAdapter(MealActivity.this,todayBreakfast);
                breakfastList.setAdapter(breakfastAdapter);
                ItemTouchHelper itemTouchHelperBreakfast = new ItemTouchHelper(new SwipeToDelete((GeneralMealAdapter) breakfastAdapter));
                itemTouchHelperBreakfast.attachToRecyclerView(breakfastList);
                breakfastAdapter.notifyDataSetChanged();

                lunchAdapter = new GeneralMealAdapter(MealActivity.this, todayLunch);
                lunchList.setAdapter(lunchAdapter);
                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeToDelete((GeneralMealAdapter) lunchAdapter));
                itemTouchHelper.attachToRecyclerView(lunchList);
                lunchAdapter.notifyDataSetChanged();

                dinnerAdapter = new GeneralMealAdapter(MealActivity.this, todayDinner);
                dinnerList.setAdapter(dinnerAdapter);
                ItemTouchHelper itemTouchHelperDinner = new ItemTouchHelper(new SwipeToDelete((GeneralMealAdapter) dinnerAdapter));
                itemTouchHelperDinner.attachToRecyclerView(dinnerList);
                dinnerAdapter.notifyDataSetChanged();
//                Log.d("size ", " ...= "+getTodayBreakfast().size());
            }
        });


//        Log.d("Time", "Current = "+ time);
        if(time.compareTo("00:00:00")>=0 && time.compareTo("10:59:59") <=0){
            addBreakfast.setBackgroundColor(Color.rgb(129,216,209));
            addLunch.setBackgroundColor(Color.TRANSPARENT);
            addDinner.setBackgroundColor(Color.TRANSPARENT);
        }
        if(time.compareTo("11:00:00")>=0 && time.compareTo("16:59:00") <=0){
            addBreakfast.setBackgroundColor(Color.TRANSPARENT);
            addLunch.setBackgroundColor(Color.rgb(129,216,209));
            addDinner.setBackgroundColor(Color.TRANSPARENT);
        }
        if(time.compareTo("17:00:00")>=0 && time.compareTo("23:59:59") <=0){
            addBreakfast.setBackgroundColor(Color.TRANSPARENT);
            addLunch.setBackgroundColor(Color.TRANSPARENT);
            addDinner.setBackgroundColor(Color.rgb(129,216,209));
        }




        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Recommendation page Button ========================
        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });
    }
}