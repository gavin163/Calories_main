package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class ManuallyAddAcitivy extends AppCompatActivity {
    private Spinner spinnerTime;
    private Button finish;
    private TextView ttype;
    private EditText tname;
    private EditText tproteins;
    private EditText tcarbs;
    private EditText tcalroies;
    private EditText tfats;
    private String type = "",name = "",proteins = "",carbs = "",calroies = "",fats = "";

    private String[] items = {"Breakfast","Lunch","Dinner"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manually_add_acitivy);
        spinnerTime = findViewById(R.id.spinnerTime);
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,items);
        spinnerTime.setAdapter(aa);
//        Meal newMeal = new Meal(type, name, 0, 0,0,0);
        type = spinnerTime.getSelectedItem().toString();
//        ttype = findViewById(R.id.TVTime);
//        ttype.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                type = s.toString();
//            }
//            @Override
//            public void afterTextChanged(Editable s) { }
//        });
        tname = findViewById(R.id.ETfoodname);
        tname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                name = s.toString();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        tproteins = findViewById(R.id.ETProtein);
        tproteins.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                proteins = s.toString();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });


        tcalroies = findViewById(R.id.ETCalories);
        tcalroies.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                calroies = s.toString();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });


        tcarbs = findViewById(R.id.ETCarbs);
        tcarbs.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                carbs = s.toString();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });


        tfats = findViewById(R.id.ETFats);
        tfats.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                fats = s.toString();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });
//        Log.d("Meal", "Test Before "+type + " "+name+" "+carbs);



        finish =  findViewById(R.id.btnmanuallyaddfinish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!name.equals("") && !calroies.equals("") && !proteins.equals("") && !carbs.equals("") && !fats.equals("")){
                    Meal p2 = new Meal(type,name,Double.parseDouble(calroies),Double.parseDouble(proteins),Double.parseDouble(carbs),Double.parseDouble(fats));
                    p2.save(new SaveListener<String>() {
                        @Override

                        public void done(String objectId,BmobException e) {
                            if(e==null){

                                Log.d( "Food is " ,p2.getMealName());
                            }else{
                                Log.d( "False Food is " ,p2.getMealName());
                            }
                        }
                    });
                }
                Intent addIntent = new Intent(ManuallyAddAcitivy.this, MealActivity.class);
                startActivity(addIntent);
            }

        });


    }
}