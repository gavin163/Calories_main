package com.example.calories;

import cn.bmob.v3.BmobObject;

public class WeightClass extends BmobObject {
    private String date, weight;

    public WeightClass(String date, double weight){
        this.date = date;
        this.weight = String.valueOf(weight);
    }

    public void setDate(String date) {
        this.date = date;
    }
    public String getDate() {
        return date;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
    public String getWeight() {
        return weight;
    }
}
