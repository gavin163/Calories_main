package com.example.calories;

import android.content.Context;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


public class WeightListAdapter extends RecyclerView.Adapter{
    private Context myContext;
//    private ArrayList<String[]> list;
    private List<WeightClass> list;

    public WeightListAdapter(Context context, List<WeightClass> incomingList){
        list = incomingList;
        myContext = context;
    }

    public class WeightViewHolder extends RecyclerView.ViewHolder{
        public TextView dateField, weightField;
        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dateField = (TextView) itemView.findViewById(R.id.dateField);
            weightField = (TextView)itemView.findViewById(R.id.weightField);
        }
    }

//    public void update(ArrayList newList){
//        list = new ArrayList<String[]>();
//        list.addAll(newList);
//        notifyDataSetChanged();
//    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.weigth_tracking_view,parent,false);
        WeightViewHolder holder = new WeightViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//        ((WeightViewHolder) holder).dateField.setText("2021-01-31");
//        ((WeightViewHolder) holder).weightField.setText("80");
//        String date = (String) list.get(position)[0];
//        String weight = (String) list.get(position)[1];
        String date = list.get(position).getDate();
        String weight = list.get(position).getWeight();
        ((WeightViewHolder) holder).dateField.setText(date);
        ((WeightViewHolder) holder).weightField.setText(weight);
    }

    @Override
    public int getItemCount() {
//        return 100;
        return list.size();
    }

}
