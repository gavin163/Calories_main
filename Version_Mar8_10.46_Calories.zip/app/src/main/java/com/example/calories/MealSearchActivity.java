package com.example.calories;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.BulletSpan;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import cn.bmob.v3.Bmob;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MealSearchActivity extends AppCompatActivity {
    private Button search;
    private Button manuallyadd;
    private EditText foodQuery;
    private RecyclerView resultFromAPI;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private ArrayList<Meal> resultList = new ArrayList<Meal>();
    private String query = "";
    private String type = "";


    class MyDecoration extends RecyclerView.ItemDecoration{
        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            outRect.set(0,0,0,getResources().getDimensionPixelOffset(R.dimen.divider));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_search);
//        Bmob.initialize(this, "a63a92d8571fb7c2e677743252cb47dd");
//        foodName = findViewById(R.id.foodName);
//        foodcal = findViewById(R.id.foodcal);

        Intent newIntent = getIntent();
        Bundle newB = newIntent.getExtras();
        type = newB.getString("type");

        foodQuery = findViewById(R.id.foodQuery);
        search = findViewById(R.id.searchButton);

        foodQuery.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                query = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        OkHttpClient client = new OkHttpClient();

        if(query.length() >= 0){
            query = query.replaceAll(" ", "%20");
        }

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Query = ", foodQuery.getText().toString());
                //                Toast.makeText(getApplicationContext(), "Clicked", Toast.LENGTH_LONG);
                String url = "https://edamam-food-and-grocery-database.p.rapidapi.com/parser?ingr=" + query;
                Request request = new Request.Builder()
                        .url(url)
                        //                        .url("https://calorieninjas.p.rapidapi.com/v1/nutrition?query=diet%20coke")
                        .get()
                        .addHeader("x-rapidapi-key", "1fee384c3bmsh090c19de42ad69dp1e6fe2jsn2d69216b9e4a")
                        .addHeader("x-rapidapi-host", "edamam-food-and-grocery-database.p.rapidapi.com")
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        if (response.isSuccessful()) {
                            final String myResponse = response.body().string();
                            MealSearchActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    resultList.clear();

                                    try {
                                        JSONObject object = new JSONObject(new String(myResponse));
                                        JSONArray jsonArray = object.getJSONArray("hints");
                                        for(int i = 0; i < jsonArray.length(); i++){
                                            String tempname = jsonArray.getJSONObject(i).getJSONObject("food").getString("label").trim();
                                            if (tempname.length()>25) {
                                                tempname =  tempname.substring(0,25) + "...";
                                            }
                                            Meal newMeal = new Meal(
                                                type, // ========================================== Need to change it to the corresponding meal type ======================================
                                                //jsonArray.getJSONObject(i).getJSONObject("food").getString("label").trim(),
                                                tempname,
                                                Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getJSONObject("food").getJSONObject("nutrients").getString("ENERC_KCAL")))),
                                                Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getJSONObject("food").getJSONObject("nutrients").getString("PROCNT")))),
                                                Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getJSONObject("food").getJSONObject("nutrients").getString("CHOCDF")))),
                                                Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getJSONObject("food").getJSONObject("nutrients").getString("FAT"))))
                                            );
                                            resultList.add(newMeal);
                                        }

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                    resultFromAPI = findViewById(R.id.resultFromApi);
                                    resultFromAPI.setHasFixedSize(true);
                                    layoutManager = new LinearLayoutManager(getApplicationContext());
                                    resultFromAPI.setLayoutManager(layoutManager);
                                    resultFromAPI.addItemDecoration(new MyDecoration());
                                    adapter = new FoodSearchAdapter(MealSearchActivity.this, resultList.isEmpty() ? new ArrayList<Meal>() : resultList);
                                    resultFromAPI.setAdapter(adapter);
                                }
                            });
                        }
                    }
                });
            }
        });
        manuallyadd = findViewById(R.id.btnmanuallyadd);
        manuallyadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addIntent = new Intent(MealSearchActivity.this, ManuallyAddAcitivy.class);
                startActivity(addIntent);
            }
        });
    }
}