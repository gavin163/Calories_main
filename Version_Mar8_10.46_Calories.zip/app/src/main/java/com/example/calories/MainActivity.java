package com.example.calories;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;

public class MainActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;
    private SharedPreferences mshare;
    private SharedPreferences.Editor mEditor;
    private TextView userName, userAge, userHeight, userWeight, userCurrentCal, userCurrentProtein, userCurrentCarb, userCurrentFat, targetCal, targetProtein, targetCarb, targetFat;
    private double calorie = 0.0, protein = 0.0, carb = 0.0, fat = 0.0;
    private final int MaleButtonID = R.id.ButtonMale, FemaleButtonID = R.id.ButtonFemale;
    private ProgressBar proteinBar, carbBar, fatBar, calorieBar;
    private AlertDialog.Builder builder;
    private Date date = new Date();

    private void setAnimation(final ProgressBar view, final int mProgressBar) {
        ValueAnimator animator = ValueAnimator.ofInt(0, mProgressBar).setDuration(1000);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                view.setProgress((int) valueAnimator.getAnimatedValue());
            }
        });
        animator.start();
    }
    private void showInput(String currentTime, String weight, SharedPreferences.Editor editor) {
        final EditText editText = new EditText(this);
        editText.setText(weight);
        builder = new AlertDialog.Builder(this).setTitle("Log your weight on " + currentTime).setView(editText)
                .setPositiveButton( "ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        editor.putString("weight", editText.getText().toString());
                        editor.commit();
                        WeightClass weightClass = new WeightClass(currentTime.replaceAll("-","/"), Double.parseDouble(editText.getText().toString()));
                        weightClass.save(new SaveListener<String>() {
                            @Override
                            public void done(String s, BmobException e) {
                                if(e==null){
                                    Toast.makeText(MainActivity.this, "Weight on "+ currentTime +" is " + editText.getText().toString()
                                            , Toast.LENGTH_LONG).show();
                                }
                            };
                        });
                        Intent intent = getIntent();
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        finish();
                        startActivity(intent);
                    }
                });
        builder.create().show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mshare = getSharedPreferences("userdata",MODE_PRIVATE);
        mEditor = mshare.edit();
        Bmob.initialize(this, "a63a92d8571fb7c2e677743252cb47dd");
        double weight = Double.parseDouble(mshare.getString("weight","0.0"));
        double height = Double.parseDouble(mshare.getString("height","0.0"));
        int age = Integer.parseInt(mshare.getString("age","0"));

        if(mshare.getString("gender","Male").equals("Male")){
            calorie = 66.47 + (13.75 * weight) + (5.003 * height) - (6.755 * age);
        }
        else{
            calorie = 655.1 + (9.563 * weight) + (1.85 * height) - (4.676 * age);
        }
        Date currentdate = new Date();//
        SimpleDateFormat current = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//
        String CurrentTime = current.format(currentdate).substring(0, 11);
        BmobQuery<WeightClass> weightQuery = new BmobQuery<WeightClass>();
        weightQuery.setLimit(1);
        weightQuery.order("-createdAt");
        weightQuery.findObjects(new FindListener<WeightClass>() {
            @Override
            public void done(List<WeightClass> list, BmobException e) {
                if(e == null){
                    if(list.get(0).getDate().compareTo(CurrentTime.replaceAll("-", "/")) != 0){
                        mEditor.putFloat("Yesterday Calorie", (float) calorie);
                        mEditor.commit();
                        showInput(CurrentTime, list.get(0).getWeight(), mEditor);
                    }
                }
            }
        });
//        showInput(CurrentTime, mshare.getString("weight","0.0"), mEditor);

        userName = findViewById(R.id.TvNameField);
        userAge = findViewById(R.id.TvAgeField);
        userHeight = findViewById(R.id.TvHeightField);
        userWeight = findViewById(R.id.TvWeightField);

        userCurrentCal = findViewById(R.id.CurrentCal);
        userCurrentCarb = findViewById(R.id.CurrentCarb);
        userCurrentFat = findViewById(R.id.CurrentFat);
        userCurrentProtein = findViewById(R.id.CurrentProtein);
        targetCal = findViewById(R.id.TargetCal);
        targetCarb = findViewById(R.id.TargetCarb);
        targetFat = findViewById(R.id.TargetFat);
        targetProtein = findViewById(R.id.TargetProtein);


        userName.setText((mshare.getString("gender","Male").equals("Male")? "Mr. ": "Ms. ") + mshare.getString("name",""));
        userAge.setText("Age: " + mshare.getString("age","0"));
        userHeight.setText(mshare.getString("height","0.0") + "CM");
        userWeight.setText(mshare.getString("weight","0.0") + "Kg");



        calorie = Double.parseDouble(new DecimalFormat("###.00").format(calorie));
        protein = calorie * 0.4 / 4;
        protein = Double.parseDouble(new DecimalFormat("###.00").format(protein));
        carb = calorie * 0.4 / 4;
        carb = Double.parseDouble(new DecimalFormat("###.00").format(carb));
        fat = calorie * 0.2 / 4;
        fat = Double.parseDouble(new DecimalFormat("###.00").format(fat));
//        Log.d("Cal", "Calories = "+String.valueOf(calorie));

        // ============== Get the meal list of today from bmob ================
        BmobQuery<Meal> query = new BmobQuery<Meal>();
        BmobQuery<Meal> q1 = new BmobQuery<Meal>();
        BmobQuery<Meal> q2 = new BmobQuery<Meal>();
        List<BmobQuery<Meal>> and = new ArrayList<BmobQuery<Meal>>();
        // =========================== Get device's time ===========================

        // =================== Use the actual date ============================
        String start = CurrentTime + " 00:00:00";
        // ====================================================================
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date  = null;
        try {
            date = sdf.parse(start);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q1.addWhereGreaterThanOrEqualTo("createdAt",new BmobDate(date));
        and.add(q1);

        // =================== Use the actual date ============================
//        String end = "2021-02-15 23:59:59";
        String end = CurrentTime + " 23:59:59";
        // ====================================================================
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1  = null;
        try {
            date1 = sdf1.parse(end);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q2.addWhereLessThanOrEqualTo("createdAt",new BmobDate(date1));
        and.add(q2);
        query.and(and);
        // ====================================================================
        query.findObjects(new FindListener<Meal>() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void done(List<Meal> list, BmobException e) {
                double currentCal = 0.0, currentProtein = 0.0, currentCarb = 0.0, currentFat = 0.0;
                if(e == null){
                    for(Meal meal : list){
                        currentCal += meal.getTotalCalorie();
                        currentProtein += meal.getTotalProtein();
                        currentCarb += meal.getTotalCarb();
                        currentFat += meal.getTotalFat();
                    }
                }
                float leftoverCal = (float) (calorie - currentCal);
                mEditor.commit();
                mEditor.putFloat("leftCal",  (float) (calorie - currentCal));
                mEditor.commit();
                mEditor.putFloat("leftPro",  (float) (protein - currentProtein));
                mEditor.commit();
                mEditor.putFloat("leftFat",  (float) (fat - currentFat));
                mEditor.commit();
                mEditor.putFloat("leftCarb", (float) (carb - currentCarb));
                mEditor.commit();
                calorieBar = findViewById(R.id.caloriesProgessBar);
                if(currentCal > calorie){
                    calorieBar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                    userCurrentCal.setTextColor(Color.RED);
                }
                else{
                    calorieBar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                    userCurrentCal.setTextColor(Color.rgb(129,216,209));
                }
                currentCal = Double.parseDouble(new DecimalFormat("###.00").format(currentCal));
                setAnimation(calorieBar, (int) ((currentCal / calorie) * 100));

                proteinBar = findViewById(R.id.proteinProgressBar);
                if(currentProtein > protein){
                    proteinBar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                    userCurrentProtein.setTextColor(Color.RED);
                }
                else{
                    proteinBar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                    userCurrentProtein.setTextColor(Color.rgb(129,216,209));
                }
                setAnimation(proteinBar, (int) ((currentProtein / protein) * 100));
                currentProtein = Double.parseDouble(new DecimalFormat("###.00").format(currentProtein));

                carbBar = findViewById(R.id.carbsProgressBar);
                if(currentCarb > carb){
                    carbBar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                    userCurrentCarb.setTextColor(Color.RED);
                }
                else{
                    carbBar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                    userCurrentCarb.setTextColor(Color.rgb(129,216,209));
                }
                setAnimation(carbBar, (int) ((currentCarb / carb) * 100));
                currentCarb = Double.parseDouble(new DecimalFormat("###.00").format(currentCarb));

                fatBar = findViewById(R.id.fatProgessBar);
                if(currentFat > fat){
                    fatBar.setProgressTintList(ColorStateList.valueOf(Color.RED));
                    userCurrentFat.setTextColor(Color.RED);
                }
                else{
                    fatBar.setProgressTintList(ColorStateList.valueOf(Color.rgb(129,216,209)));
                    userCurrentFat.setTextColor(Color.rgb(129,216,209));
                }
                setAnimation(fatBar, (int) ((currentFat / fat) * 100));
                currentFat = Double.parseDouble(new DecimalFormat("###.00").format(currentFat));

                userCurrentCal.setText(String.valueOf(currentCal));
                userCurrentCarb.setText(String.valueOf(currentCarb));
                userCurrentFat.setText(String.valueOf(currentFat));
                userCurrentProtein.setText(String.valueOf(currentProtein));
                targetCal.setText(String.valueOf(calorie) +"Kcal");
                targetCarb.setText(String.valueOf(carb) + "g");
                targetFat.setText(String.valueOf(fat) + "g");
                targetProtein.setText(String.valueOf(protein) + "g");

            }
        });



        // =================== Replace with the real data ===================
//        double currentCal = 100.00, currentProtein = 100.00, currentCarb = 100.00, currentFat = 50.00;
        // ==================================================================
//        calorieBar = findViewById(R.id.caloriesProgessBar);
////        calorieBar.setProgress((int) ((currentCal / calorie) * 100));
//        setAnimation(calorieBar, (int) ((currentCal / calorie) * 100));
//        proteinBar = findViewById(R.id.proteinProgressBar);
//        setAnimation(proteinBar, (int) ((currentProtein / protein) * 100));
////        proteinBar.setProgress((int) ((currentProtein / protein) * 100));
//        carbBar = findViewById(R.id.carbsProgressBar);
//        setAnimation(carbBar, (int) ((currentCarb / carb) * 100));
////        carbBar.setProgress((int) ((currentCarb / carb) * 100));
//        fatBar = findViewById(R.id.fatProgessBar);
//        setAnimation(fatBar, (int) ((currentFat / fat) * 100));
////        fatBar.setProgress((int) ((currentFat / fat) * 100));
//
//
//        userCurrentCal.setText(String.valueOf(currentCal));
//        userCurrentCarb.setText(String.valueOf(currentCarb));
//        userCurrentFat.setText(String.valueOf(currentFat));
//        userCurrentProtein.setText(String.valueOf(currentProtein));
//        targetCal.setText(String.valueOf(calorie) +"Kcal");
//        targetCarb.setText(String.valueOf(carb) + "g");
//        targetFat.setText(String.valueOf(fat) + "g");
//        targetProtein.setText(String.valueOf(protein) + "g");



//        userCalTracking.setText( String.valueOf(currentCal) + " / "+ String.valueOf(calorie) +" Kcal");
//        userProteinTracking.setText(String.valueOf(currentProtein) + " / " + String.valueOf(protein) + "g");
//        userCarbTracking.setText(String.valueOf(currentCarb) + " / "+ String.valueOf(carb) + "g");
//        userFatTracking.setText(String.valueOf(currentFat) + " / "+ String.valueOf(fat) + "g");



        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Recommendation page Button ========================
        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

    }


}