package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.icu.lang.UCharacter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class CalendarActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;
    private TextView graphTitle;
    private RecyclerView weightRecyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private GraphView graph;

    // A list that contains weight with its corresponding date.
//    private ArrayList<String[]> weightList;

    private BmobQuery<WeightClass> query = new BmobQuery<WeightClass>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        Bmob.initialize(this, "a63a92d8571fb7c2e677743252cb47dd");
        graph = (GraphView) findViewById(R.id.weightGraph);

        weightRecyclerView = (RecyclerView)findViewById(R.id.weightList);
        weightRecyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        weightRecyclerView.setLayoutManager(layoutManager);

//        String[] t1 = {"2021-01-01", "80"};
//        String[] t2 = {"2021-01-02", "81"};
//        String[] t3 = {"2021-01-03", "82"};
//        String[] t4 = {"2021-01-04", "83"};
//        String[] t5 = {"2021-01-05", "84"};
//        String[] t6 = {"2021-01-06", "80"};
//        weightList.add(t1);
//        weightList.add(t2);
//        weightList.add(t3);
//        weightList.add(t4);
//        weightList.add(t5);
//        weightList.add(t6);

        // =================== Retrieve data from bmob ===================
        query.setLimit(30);
        query.order("-createdAt");
        query.findObjects(new FindListener<WeightClass>() {

            @Override
            public void done(List<WeightClass> list, BmobException e) {
//                Log.d("error", "error " + e.toString());
//                Log.d("List", "List = "+list.size());
//                for(WeightClass weight : list){
//                    weightList.add(new String[]{weight.getDate(), weight.getWeight()});
//                }
                if(e == null){
                    int size = list.size();
                    ArrayList<String[]> weightList = new ArrayList<String[]>();
//                    Log.d("List", "List = "+String.valueOf(size));
                    adapter = new WeightListAdapter(CalendarActivity.this, list);
                    weightRecyclerView.setAdapter(adapter);
                    for(int i = size - 1; i >= 0; i--){
                        weightList.add(new String[]{list.get(i).getDate(), list.get(i).getWeight()});
                    }
                    DataPoint[] data = new DataPoint[weightList.size()];

                    for(int i = 0; i < size; i++){
//                        double day = Double.parseDouble(weightList.get(i)[0].replaceAll("-",""));
                        double w = Double.parseDouble(weightList.get(i)[1]);
                        Log.d("List", "List = "+String.valueOf(w));
                        data[i] = new DataPoint(i + 1, w);
                    }
                    LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(data);
                    series.setAnimated(true);
                    series.setThickness(5);
                    series.setDrawBackground(false);
                    series.setColor(Color.rgb(129,216,209));

                    series.setDrawDataPoints(true);
                    graph.addSeries(series);
                    graph.getGridLabelRenderer().setNumHorizontalLabels(data.length);
                    graph.getGridLabelRenderer().setGridColor(Color.rgb(68,68,68));
                    graph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.HORIZONTAL);
                    graph.getGridLabelRenderer().setLabelHorizontalHeight(20);
                    graph.getGridLabelRenderer().setSecondScaleLabelVerticalWidth(30);
                }


//                ((WeightListAdapter)adapter).update(weightList);

                graphTitle = findViewById(R.id.GraphTitle);
                graphTitle.setText(" ");


            }
        });
        // ===============================================================





//        graphTitle = findViewById(R.id.GraphTitle);
//        graphTitle.setText(" ");
//
//        DataPoint[] data = new DataPoint[weightList.size()];
//
//        for(int i = 0; i < weightList.size(); i++){
//            double day = Double.parseDouble(weightList.get(i)[0].replaceAll("-",""));
//            double w = Double.parseDouble(weightList.get(i)[1]);
//            data[i] = new DataPoint(i+1, w);
//        }
//        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(data);
//        series.setAnimated(true);
//        series.setThickness(5);
//        series.setDrawBackground(false);
//        series.setColor(Color.rgb(129,216,209));
//
//        series.setDrawDataPoints(true);
//        graph.addSeries(series);
//        graph.getGridLabelRenderer().setNumHorizontalLabels(data.length);
//        graph.getGridLabelRenderer().setGridColor(Color.rgb(68,68,68));
//        graph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.HORIZONTAL);
//        graph.getGridLabelRenderer().setLabelHorizontalHeight(20);
//        graph.getGridLabelRenderer().setSecondScaleLabelVerticalWidth(30);






        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(CalendarActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(CalendarActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(CalendarActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(CalendarActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Recommendation page Button ========================
        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(CalendarActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(CalendarActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });
    }
}