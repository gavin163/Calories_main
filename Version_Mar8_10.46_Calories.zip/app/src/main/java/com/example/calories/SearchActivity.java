package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SearchActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
//    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;
    private RecyclerView resultFromAPI;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private SharedPreferences mshare;
    private SharedPreferences.Editor mEditor;
    private String[] items = {"Breakfast","Lunch","Dinner"};
    private Spinner mealTypeMenu;
    private String chosenType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        ArrayList<Meal> recommendationArray = new ArrayList<Meal>();

        mealTypeMenu =  findViewById(R.id.mealTypeMenu);
        ArrayAdapter<String> bb = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,items);
        mealTypeMenu.setAdapter(bb);



        mshare = getSharedPreferences("userdata", MODE_PRIVATE);
        double availCal = Double.parseDouble(new DecimalFormat("####.00").format(mshare.getFloat("leftCal", (float) 0.0)));
        if(availCal <= 0){
            availCal = 0;
        }
        double availPro = Double.parseDouble(new DecimalFormat("####.00").format(mshare.getFloat("leftPro", (float) 0.0)));
        if(availPro <= 0){
            availPro = 0;
        }
        double availFat = Double.parseDouble(new DecimalFormat("####.00").format(mshare.getFloat("leftFat", (float) 0.0)));
        if(availFat <= 0){
            availFat = 0;
        }
        double availCarb = Double.parseDouble(new DecimalFormat("####.00").format(mshare.getFloat("leftCarb", (float) 0.0)));
        if(availCarb <= 0){
            availCarb = 0;
        }
        mEditor = mshare.edit();
//        mEditor.putString("Chosen Type", "Breakfast");
//        mEditor.commit();
        mealTypeMenu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(SearchActivity.this, "choose " + items[position], Toast.LENGTH_LONG).show();
                mealTypeMenu.setSelection(position);
                String type = items[position];
                chosenType = type;

                mEditor.putString("Chosen Type", items[position]);
                mEditor.commit();
                Log.d("Type", "SAType = " + mshare.getString("Chosen Type"," "));

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        String maxCal = "maxCalories="+String.valueOf(availCal), maxPro = "maxProtein="+String.valueOf(availPro), maxCarb = "maxCarbs="+String.valueOf(availCarb), maxFat = "maxFat="+String.valueOf(availFat);
        OkHttpClient client = new OkHttpClient();
        String query = "https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/findByNutrients?minCarbs=0&minProtein=0&number=10&random=true&minFat=5&minCalories=0&";
        query += maxCal + "&" + maxPro + "&" + maxCarb + "&" + maxFat ;
        Request request = new Request.Builder()
                .url(query)
                .get()
                .addHeader("x-rapidapi-key", "1fee384c3bmsh090c19de42ad69dp1e6fe2jsn2d69216b9e4a")
                .addHeader("x-rapidapi-host", "spoonacular-recipe-food-nutrition-v1.p.rapidapi.com")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String myResponse = response.body().string();
                    SearchActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            recommendationArray.clear();
                            try {
                                JSONArray jsonArray = new JSONArray(new String(myResponse));
                                for(int i = 0; i < jsonArray.length(); i++){
                                    String tempname = jsonArray.getJSONObject(i).getString("title").trim();
                                    Meal newMeal = new Meal(
                                            "",
                                            tempname,
                                            Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getString("calories").trim()))),
                                            Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getString("protein").trim().replaceAll("g", "")))),
                                            Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getString("carbs").trim().replaceAll("g", "")))),
                                            Double.parseDouble(new DecimalFormat("###.00").format(Double.parseDouble(jsonArray.getJSONObject(i).getString("fat").trim().replaceAll("g", ""))))
                                    );
                                    newMeal.setImage(jsonArray.getJSONObject(i).getString("image").trim());
                                    recommendationArray.add(newMeal);
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            resultFromAPI = findViewById(R.id.recommendedMeal);
                            resultFromAPI.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
                            adapter = new RecommendedFood(SearchActivity.this, recommendationArray);
                            resultFromAPI.setAdapter(adapter);
                        }
                    });
                }
            }
        });
//        String name = "Anchovies With Breadcrumbs & Scallions";
//        double carbs = availCarb;
//        double fat = availFat;
//        double protein = availPro;
//        double calorie = availCal;
//        String image = "https://spoonacular.com/recipeImages/fish-tagine-with-tomatoes-capers-and-cinnamon-2-111567.jpg";
//        Meal test = new Meal( "", name, calorie, protein, carbs, fat);
//        mealTypeMenu =  findViewById(R.id.mealTypeMenu);
//        final String mealT = "";
//        mealTypeMenu.setAdapter(bb);
//        for(int i = 0; i < 5; i++){
//            test.setImage(image);
//            recommendationArray.add(test);
//        }
//
//        resultFromAPI = findViewById(R.id.recommendedMeal);
//        resultFromAPI.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
//        adapter = new RecommendedFood(SearchActivity.this, recommendationArray);
//        resultFromAPI.setAdapter(adapter);






        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

//        // ======================== Recommendation page Button ========================
//        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
//        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Intent settingIntent = new Intent(SearchActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
//                startActivity(settingIntent);
//            }
//        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });
    }
}