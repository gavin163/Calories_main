package com.example.calories;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class FoodSearchAdapter extends RecyclerView.Adapter {
    private Context mycontext;
    private ArrayList<Meal> currentList = new ArrayList<Meal>();
    private SharedPreferences mshare;
    private SharedPreferences.Editor mEditor;

    public FoodSearchAdapter(Context context, ArrayList<Meal> foodlist){
        mycontext = context;
        currentList = foodlist;
        mshare = mycontext.getSharedPreferences("userdata", Context.MODE_PRIVATE);
        mEditor = mshare.edit();
    }
    public class SearchMealViewHolder extends RecyclerView.ViewHolder{
        public TextView foodName, foodCal, foodPro, foodCarb, foodFat;

        public SearchMealViewHolder(@NonNull View itemView) {
            super(itemView);
            foodName = (TextView) itemView.findViewById(R.id.foodName);
            foodCal = (TextView) itemView.findViewById(R.id.calorie);
//            foodPro = (TextView) itemView.findViewById(R.id.protein);
//            foodCarb = (TextView) itemView.findViewById(R.id.carb);
//            foodFat = (TextView) itemView.findViewById(R.id.fat);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.food_from_query,parent,false);
        FoodSearchAdapter.SearchMealViewHolder holder = new FoodSearchAdapter.SearchMealViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((SearchMealViewHolder) holder).foodName.setText( currentList.get(position).getMealName());
        ((SearchMealViewHolder) holder).foodCal.setText( Double.toString(currentList.get(position).getTotalCalorie()) + "Kcal");
        ((SearchMealViewHolder) holder).foodName.setTextColor(Color.BLACK);
        ((SearchMealViewHolder) holder).foodCal.setTextColor(Color.BLACK);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((SearchMealViewHolder) holder).foodName.setTextColor(Color.rgb(129,216,209));
                ((SearchMealViewHolder) holder).foodCal.setTextColor(Color.rgb(129,216,209));
                // TODO: Click the item and add it to the corresponding meal type (Breakfast, lunch, or dinner)
                currentList.get(position).save(new SaveListener<String>() {
                    @Override
                    public void done(String s, BmobException e) {
                        if(e==null){
                            Log.d( "Food is " , currentList.get(position).getMealName());
                        }else{
                            Log.d( "Failed in " , currentList.get(position).getMealName());
                        }
                    };
                });
                float calorie = mshare.getFloat("leftCal", (float) 0.0);
                float protein = mshare.getFloat("leftPro", (float) 0.0);
                float fat = mshare.getFloat("leftFat", (float) 0.0);
                float carb = mshare.getFloat("leftCarb", (float) 0.0);
                mEditor.putFloat("leftCal",  (float) (calorie - currentList.get(position).getTotalCalorie()));
                mEditor.putFloat("leftPro",  (float) (protein - currentList.get(position).getTotalProtein()));
                mEditor.putFloat("leftFat",  (float) (fat - currentList.get(position).getTotalFat()));
                mEditor.putFloat("leftCarb", (float) (carb - currentList.get(position).getTotalCarb()));
                mEditor.commit();
                // after adding it to the list, go back to the meal activity page.
                Intent mealActivity = new Intent(mycontext, MealActivity.class); // Should jump to the real destination
                mycontext.startActivity(mealActivity);
            }
        });
//        ((SearchMealViewHolder) holder).foodPro.setText( "Protein: " + Double.toString(currentList.get(position).getTotalProtein()) + "g");
//        ((SearchMealViewHolder) holder).foodCarb.setText( "Carbs: "+ Double.toString(currentList.get(position).getTotalCarb()) + "g");
//        ((SearchMealViewHolder) holder).foodFat.setText( "Fat: " + Double.toString(currentList.get(position).getTotalFat()) + "g");

    }

    @Override
    public int getItemCount() {
//        Log.d("Length ==", Integer.toString(currentList.size()));
        return currentList.isEmpty()? 0 : currentList.size();
//        return 0;
    }

    public interface MealItemClickListener{
        void OnClick(int position);
    }

}
