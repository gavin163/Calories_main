package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class SettingActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;
    private Button submitButton;
    private Button goalButton;

    private EditText userName, userAge, userHeight, userWeight;
    private RadioGroup userGender;

    private String name = "", gender = "";
    private double height = 0.0, weight = 0.0;
    private double calorie = 0.0, protein = 0.0, carb = 0.0, fat = 0.0;
    private int age = 0;
    private int genderID = 0;
    private SharedPreferences mshare;
    private SharedPreferences.Editor mEditor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        mshare = getSharedPreferences("userdata",MODE_PRIVATE);
        mEditor = mshare.edit();


        userName = findViewById(R.id.settingNametext);
        name = mshare.getString("name","");

        userName.setText(mshare.getString("name"," "));
        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                name = s.toString();
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                name = s.toString();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        userAge = findViewById(R.id.settingAge);
        age = Integer.parseInt(mshare.getString("age","0"));
        userAge.setText(mshare.getString("age",""));
        userAge.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().isEmpty()) {
                    age = Integer.parseInt(s.toString());
                }
                else{
                    age = 0;
                }
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        userHeight = findViewById(R.id.settingHeight);
        height = Double.parseDouble(mshare.getString("height","0.0"));

        userHeight.setText(mshare.getString("height",""));
        userHeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().isEmpty()) {
                    height = Double.parseDouble(s.toString());
                }
                else{
                    height = 0;
                }
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        userWeight = findViewById(R.id.settingWeight);
        weight = Double.parseDouble(mshare.getString("weight","0.0"));
        userWeight.setText(mshare.getString("weight",""));
        userWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().isEmpty()) {
                    weight = Double.parseDouble(s.toString());
                }
                else {
                    weight = 0;
                }
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });


        gender = mshare.getString("gender","Male");
        userGender = findViewById(R.id.GenderRG);

        RadioButton rbtnMale =  findViewById(R.id.ButtonMale);
        RadioButton rbtnFeMale =  findViewById(R.id.ButtonFemale);

        if(gender.equals("Male")){
            if(!rbtnMale.isChecked()){
                rbtnMale.setChecked(true);
                rbtnFeMale.setChecked(false);
            }
        }
        else{
            if(!rbtnFeMale.isChecked()){
                rbtnFeMale.setChecked(true);
                rbtnMale.setChecked(false);
            }
        }

        userGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton chosenGender = group.findViewById(checkedId);
                genderID = checkedId;
                switch (checkedId){
                    case R.id.ButtonFemale:
                        gender = "Female";
                        break;
                    case R.id.ButtonMale:
                        gender = "Male";
                        break;
                }
            }
        });


//        BMR for Men = 66.47 + (13.75 * weight [kg]) + (5.003 * size [cm]) − (6.755 * age [years])
//        BMR for Women = 655.1 + (9.563 * weight [kg]) + (1.85 * size [cm]) − (4.676 * age [years])
//        2000 * 0.4 calories from protein / 4 = 200 g Protein
//        2000 * 0.4 calories from carbs / 4 = 200 g carbs
//        2000 * 0.2 calories from fat / 9 = 45 g fat
//        calorie = Double.parseDouble(mshare.getString("calorie", "0.0"));
//        protein = Double.parseDouble(mshare.getString("protein", "0.0"));
//        carb = Double.parseDouble(mshare.getString("carb", "0.0"));
//        fat = Double.parseDouble(mshare.getString("fat", "0.0"));
//
//        if(gender.equals("Male")){
//            calorie = 66.47 + (13.75 * weight) + (5.003 * height) - (6.755 * age);
//        }
//        else{
//            calorie = 655.1 + (9.563 * weight) + (1.85 * height) - (4.676 * age);
//        }
//        calorie = Double.parseDouble(new DecimalFormat("###.00").format(calorie));
//        protein = calorie * 0.4 / 4;
//        protein = Double.parseDouble(new DecimalFormat("###.00").format(protein));
//        carb = calorie * 0.4 / 4;
//        carb = Double.parseDouble(new DecimalFormat("###.00").format(carb));
//        fat = calorie * 0.2 / 4;
//        fat = Double.parseDouble(new DecimalFormat("###.00").format(fat));
















//        goalButton = findViewById(R.id.buttongoal);
//        goalButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent goalIntent = new Intent(SettingActivity.this,GoalActivity.class);
//                startActivity(goalIntent);
//            }
//        });
        submitButton = findViewById(R.id.submitPersonalInfo);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date currentdate = new Date();//
                SimpleDateFormat current = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//
                String CurrentTime = current.format(currentdate).substring(0, 11);
                WeightClass weightClass = new WeightClass(CurrentTime.replaceAll("-","/"), weight);
                weightClass.save(new SaveListener<String>() {
                    @Override
                    public void done(String s, BmobException e) {
                        if(e==null){
                            Log.d( "Food is " , weightClass.getDate());
                        }else{
                            Log.d( "Failed in " , "FFFF");
                        }
                    };
                });
                mEditor.putString("name",       name);
                mEditor.commit();
                mEditor.putString("age",        String.valueOf(age));
                mEditor.commit();
                mEditor.putString("height",     String.valueOf(height));
                mEditor.commit();
                mEditor.putString("weight",     String.valueOf(weight));
                mEditor.commit();
                mEditor.putString("gender",     String.valueOf(gender));
                mEditor.commit();
//                mEditor.putString("calorie",    String.valueOf(calorie));
//                mEditor.commit();
//                mEditor.putString("protein",    String.valueOf(protein));
//                mEditor.commit();
//                mEditor.putString("carb",       String.valueOf(carb));
//                mEditor.commit();
//                mEditor.putString("fat",        String.valueOf(fat));
//                mEditor.commit();
                Intent submit = new Intent(SettingActivity.this, MainActivity.class);
                startActivity(submit);
            }
        });

        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SettingActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SettingActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SettingActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SettingActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Recommendation page Button ========================
        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SettingActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SettingActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });
    }
}